﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication8
{ 
    class Methods
{
    static OleDbConnection con;
    static OleDbCommand cmd;
    static OleDbDataReader reader;


    public static char MainMethod()
    {
        Console.WriteLine("\t\t \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\");
        Console.WriteLine("\t\t======================================================");
        Console.WriteLine("\t\t\t        SCHOOL MANAGEMENT SYSTEM ");
        Console.WriteLine("\t\t======================================================");
        Console.WriteLine("\t\t \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\");
        Console.WriteLine();
        Console.WriteLine();
        Console.WriteLine("\t\t\t\t Enter Your Choice : ");
        Console.WriteLine("\t\t\t\t 1 for Students Information");
        Console.WriteLine("\t\t\t\t 2 for Teachers Information");
        Console.WriteLine("\t\t\t\t 3 for Specific BloodGroup Students");
        Console.WriteLine("\t\t\t\t 4 for Exit Program");
        Console.WriteLine("Enter Choice");
        char Choice = Convert.ToChar(Console.ReadLine());
        return Choice;
        } 

        public static char StudentMethod()
    {
        {
            Console.WriteLine("\t\t \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\");
            Console.WriteLine("\t\t======================================================");
            Console.WriteLine("\t\t\t        For Student InFormation");
            Console.WriteLine("\t\t======================================================");
            Console.WriteLine("\t\t \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\");
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("\t\t\t\t 1 for New Entry");
            Console.WriteLine("\t\t\t\t 2 for Search Records");
            Console.WriteLine("\t\t\t\t 3 for Delete Records");
            Console.WriteLine("\t\t\t\t 4 for Update Records");
            Console.WriteLine("\t\t\t\t 5 for Go To main");

            Console.WriteLine("Enter Choice");
            char pic = Convert.ToChar(Console.ReadLine());
            return pic;
        }
    } 
    public static void StudentInsert()
    {

        Console.WriteLine("Enter Firstname");
        string FirstName = Convert.ToString(Console.ReadLine());
        Console.WriteLine("Enter LastName");
        string LastName = Convert.ToString(Console.ReadLine());
        Console.WriteLine("Enter Contact");
        string Contact = Convert.ToString(Console.ReadLine());
        Console.WriteLine("Enter BloodGroup");
        string BloodGroup = Convert.ToString(Console.ReadLine());
        Console.WriteLine("Enter  Address ");
        string Address = Convert.ToString(Console.ReadLine());
        Console.WriteLine("Enter  Class");
        string Class = Convert.ToString(Console.ReadLine());
        Console.WriteLine("Enter AdmissionYear");
        string AdmissionYear = Convert.ToString(Console.ReadLine());
        con = new OleDbConnection();
        con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=SMS.accdb";
        con.Open();
        cmd = new OleDbCommand();
        cmd.Connection = con;
        cmd.CommandText = "INSERT INTO StudentTbl (FirstName,LastName,Contact,BloodGroup,HouseAddress,Class,AdmissionYear) VALUES ('" + FirstName + "','" + LastName + "','" + Contact + "','" + BloodGroup + "','" + Address + "','" + Class + "','" + AdmissionYear + "')";
        int sonuc = cmd.ExecuteNonQuery();
        con.Close();
        if (sonuc > 0)
        {
            Console.WriteLine("Inserted");

        }
        else
        {
            Console.WriteLine("There are errors. The record was not inserted.");
        }
        }  
    public static void studentslect()
    {
      
            Console.WriteLine("Enter Firstname");
            string Firstname = Convert.ToString(Console.ReadLine());
            Console.WriteLine("Enter LastName");
            string LastName = Convert.ToString(Console.ReadLine());
            con = new OleDbConnection();
            con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=SMS.accdb";
            con.Open();
            cmd = new OleDbCommand();
            cmd.Connection = con;
            cmd.CommandText = "SELECT * FROM StudentTbl where FirstName ='" + Firstname + "' and LastName = '" + LastName + "'";

            reader = cmd.ExecuteReader();
            if (reader.HasRows) 
            {
                while (reader.Read()) 
                {
                    Console.WriteLine(reader[1] + " - " + reader[2] + " - " + reader[3] + " - " + reader[4] + " - " + reader[5] + " - " + reader[6] + " - " + reader[7]);
                }

                con.Close();
                Console.ReadKey();
            }
            else
            {
                Console.WriteLine("No Student found");
                Console.ReadKey();
            }
        
    }    

    public static void studentsselete()
    {
        {

            Console.WriteLine("Enter RegistrationNo");
            int RegistrationNo = Convert.ToInt32(Console.ReadLine());
            con = new OleDbConnection();
            con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=SMS.accdb";
            cmd = new OleDbCommand();
            cmd.Connection = con;
            cmd.CommandText = "DELETE FROM StudentTbl WHERE ID=" + RegistrationNo;

            con.Open();
            int sonuc = cmd.ExecuteNonQuery();
            con.Close();
            if (sonuc > 0)
            {
                Console.WriteLine("Student Deleted.");
                Console.ReadKey();
            }
            else
            {
                Console.WriteLine("No Record found and not deleted.");
                Console.ReadKey();
            }
        }
    }

    public static void studentsUpdate()
    {
        Console.WriteLine("Enter RegistrationNo");
        int RegistrationNo = Convert.ToInt32(Console.ReadLine());
        con = new OleDbConnection();
        con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=SMS.accdb";
        cmd = new OleDbCommand();
        cmd.Connection = con;
        cmd.CommandText = "select * FROM StudentTbl WHERE ID=" + RegistrationNo;
        con.Open();
        reader = cmd.ExecuteReader();
        if (reader.HasRows) //rows milin ya nahi
        {
            while (reader.Read()) //while used for multiple records 
            {
                Console.WriteLine("FirstName: " + reader[1] + "  Lastname: " + reader[2] + "  Conatct: " + reader[3] + "  BloodGroup: " + reader[4] + "  HouseAddress: " + reader[5] + "  Class: " + reader[6] + "  AdmissionYear" + reader[7]);
            }
        }
        Console.WriteLine("which fields you want to update");
        Console.WriteLine("Can you want to change Firstname & Lastname? if yes then press 1");
        Console.WriteLine("Can you want to change Contact? if yes then press 2");
        Console.WriteLine("Can you want to change HouseAddress? if yes then press 3");
        Console.WriteLine("Can you want to change Class? if yes then press 4");

        char c = Convert.ToChar(Console.ReadLine());
        if (c == '1')
        {
            Console.Write("First Name : ");
            string fname = Console.ReadLine();
            Console.Write("Last Name : ");
            string lname = Console.ReadLine();

            con = new OleDbConnection();
            con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=SMS.accdb";
            cmd = new OleDbCommand();
            cmd.Connection = con;
            cmd.CommandText = "UPDATE StudentTbl SET FirstName='" + fname + "',LastName='" + lname + "' WHERE Id=" + RegistrationNo;

            con.Open();
            int sonuc = cmd.ExecuteNonQuery();
            con.Close();
            if (sonuc > 0)
            {
                Console.WriteLine("Updated");
            }
            else
            {
                Console.WriteLine("Three are errors. The record was not updated");
            }
        }
        if (c == '2')
        {
            Console.WriteLine("Enter Contact");
            string Contact = Convert.ToString(Console.ReadLine());
            con = new OleDbConnection();
            con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=SMS.accdb";
            cmd = new OleDbCommand();
            cmd.Connection = con;
            cmd.CommandText = "UPDATE StudentTbl SET Contact='" + Contact + "' WHERE Id=" + RegistrationNo;

            con.Open();
            int sonuc = cmd.ExecuteNonQuery();
            con.Close();
            if (sonuc > 0)
            {
                Console.WriteLine("Updated");
            }
            else
            {
                Console.WriteLine("Three are errors. The record was not updated");
            }
        }

        if (c == '3')
        {
            Console.WriteLine("Enter  Address ");
            string Address = Convert.ToString(Console.ReadLine());
        }
        if (c == '4')
        {
            Console.WriteLine("Enter  Class");
            string Class = Convert.ToString(Console.ReadLine());
            con = new OleDbConnection();
            con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=SMS.accdb";
            cmd = new OleDbCommand();
            cmd.Connection = con;
            cmd.CommandText = "UPDATE StudentTbl SET Class='" + Class + "' WHERE Id=" + RegistrationNo;
            con.Open();
            int sonuc = cmd.ExecuteNonQuery();
            con.Close();
            if (sonuc > 0)
            {
                Console.WriteLine("Updated");
            }
            else
            {
                Console.WriteLine("Three are errors. The record was not updated");
            }
        }
    }
        public static char Teachermain()
        {
            Console.WriteLine("\t\t \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\");
            Console.WriteLine("\t\t======================================================");
            Console.WriteLine("\t\t\t        For Teacher InFormation");
            Console.WriteLine("\t\t======================================================");
            Console.WriteLine("\t\t \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\");
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("\t\t\t\t 1 for New Entry");
            Console.WriteLine("\t\t\t\t 2 for Search Records");
            Console.WriteLine("\t\t\t\t 3 for Delete Records");
            Console.WriteLine("\t\t\t\t 4 for Go To main");
            char select = Convert.ToChar(Console.ReadLine());
            return select;
        }
    public static void Teacherinsert()
    {
        Console.WriteLine("Enter Firstname");
        string FirstName = Convert.ToString(Console.ReadLine());
        Console.WriteLine("Enter LastName");
        string LastName = Convert.ToString(Console.ReadLine());
        Console.WriteLine("Enter Contact");
        string Contact = Convert.ToString(Console.ReadLine());
        Console.WriteLine("Enter BloodGroup");
        string BloodGroup = Convert.ToString(Console.ReadLine());
        Console.WriteLine("Enter Qualification");
        string Qualification = Convert.ToString(Console.ReadLine());
        Console.WriteLine("Enter WeekPeriod");
        int WeekPeriod = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Enter Specialization");
        string Specialization = Convert.ToString(Console.ReadLine());

        Console.WriteLine("Enter  Address");
        string Address = Convert.ToString(Console.ReadLine());
        con = new OleDbConnection();
        con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=SMS.accdb";
        cmd = new OleDbCommand();
            cmd.Connection = con;
            cmd.CommandText = "INSERT INTO Teachertbl (FirstName,LastName,Contact,BloodGroup,Qualification,WeekPeriods,Specialization, Address) VALUES ('" + FirstName + "','" + LastName + "','" + Contact + "','" + BloodGroup + "','" + Qualification + "'," + WeekPeriod + ",'" + Specialization + "','" + Address + "')";
        con.Open();
        int sonuc = cmd.ExecuteNonQuery();
        con.Close();
        if (sonuc > 0)
        {
            Console.WriteLine("Inserted");

        }
        else
        {
            Console.WriteLine("Three are errors. The record was not inserted.");
        }
    }
    public static void Teacherselect()
    {
        Console.WriteLine("Enter Firstname");
        string Firstname = Convert.ToString(Console.ReadLine());
        Console.WriteLine("Enter LastName");
        string LastName = Convert.ToString(Console.ReadLine());
        con = new OleDbConnection();
        con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=SMS.accdb";
        con.Open();
        cmd = new OleDbCommand();
        cmd.Connection = con;
        cmd.CommandText = "SELECT * FROM Teachertbl where FirstName ='" + Firstname + "' and LastName = '" + LastName + "'";

        reader = cmd.ExecuteReader();
        if (reader.HasRows) //rows milin ya nahi
        {
            while (reader.Read()) //while used for multiple records 
            {
                Console.WriteLine(reader[1] + " - " + reader[2] + " - " + reader[3] + " - " + reader[4] + " - " + reader[5] + " - " + reader[6] + " - " + reader[7] + " - " + reader[8]);
            }

            con.Close();
            Console.ReadKey();
        }
        else
        {
            Console.WriteLine("No Teacher found");
            Console.ReadKey();
        }
    }


    public static void Teacherdelete()
    {
        Console.WriteLine("Enter RegistrationNo");
        int RegistrationNo = Convert.ToInt32(Console.ReadLine());
        con = new OleDbConnection();
        con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=SMS.accdb";
        cmd = new OleDbCommand();
        cmd.Connection = con;
        cmd.CommandText = "DELETE FROM Teachertbl WHERE ID=" + RegistrationNo;
        con.Open();
        int sonuc = cmd.ExecuteNonQuery();
        con.Close();
        if (sonuc > 0)
        {
            Console.WriteLine("Student Deleted.");
            Console.ReadKey();
        }
        else
        {
            Console.WriteLine("No Record found and not deleted.");
            Console.ReadKey();
        }

    }
    public static void blood()
    {
            Console.WriteLine(" ---------------------------------");
            Console.WriteLine("|\t Search Blood Group       |");
            Console.WriteLine(" ---------------------------------");
            Console.WriteLine("Enter Blood Group");
            Console.WriteLine();
        string bloodGroup = Convert.ToString(Console.ReadLine());
        con = new OleDbConnection();
        con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=SMS.accdb";
        cmd = new OleDbCommand();
        cmd.Connection = con;
        cmd.CommandText = "SELECT * FROM StudentTbl where BloodGroup=@BloodGroup";
        cmd.Parameters.AddWithValue("BloodGroup", bloodGroup);
        con.Open();
        reader = cmd.ExecuteReader();
        if (reader.HasRows)
        {
            while (reader.Read())  //use kar rahe hu 
            {
                Console.WriteLine("Name: " + reader[1] + " " + reader[2] + "\tClass: " + reader[6]);
            }
            Console.ReadKey();
            con.Close();
        }
        else
        {
            Console.WriteLine("No Student found");
            Console.ReadKey();
        } }

        public static bool Login()
        {
            Console.WriteLine("Enter Username");
            string username = Convert.ToString(Console.ReadLine());
            Console.WriteLine("Enter Password");
            string password = Convert.ToString(Console.ReadLine());
            con = new OleDbConnection();
            con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=SMS.accdb";
            con.Open(); 
            cmd = new OleDbCommand();
            cmd.Connection = con;
            cmd.CommandText = "SELECT * FROM Login where Username ='" + username + "' and Password = '" + password + "'";
            reader = cmd.ExecuteReader();
            if (reader.HasRows) //rows milin ya nahi
            {

                con.Close();
                return true;
            }
            else
            {
                con.Close();
                return false;
            }
        }
    }
}
       
        