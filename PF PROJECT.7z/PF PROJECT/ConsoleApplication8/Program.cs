﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication8
{
    class Program
    {
        static OleDbConnection con;
        static OleDbCommand cmd;
        static OleDbDataReader reader;
        static void Main(string[] args)
        {

            if (Methods.Login())
            {
                for (int i = 1; i > 0; i++)
                {
                    if (i >= 2)
                    {
                        Console.Write("Do You Want To Continue Pree S And Close For C : ");
                        char ch = Convert.ToChar(Console.ReadLine());
                        if (ch == 's' || ch == 'S')
                        {
                            Console.Clear();
                            char Choice = Methods.MainMethod();
                            Console.Clear();
                            switch (Choice)
                            {
                                case '1':
                                    {
                                        Console.Clear();
                                        char pic = Methods.StudentMethod();
                                        switch (pic)
                                        {
                                            case '1':
                                                {
                                                    Methods.StudentInsert();
                                                    break;
                                                }
                                            case '2':
                                                {
                                                    Methods.studentslect();
                                                    break;
                                                }
                                            case '3':
                                                {
                                                    Methods.studentsselete();
                                                    break;
                                                }
                                            case '4':
                                                {
                                                    Methods.studentsUpdate();
                                                    break;
                                                }
                                            default:
                                                break;
                                        }
                                        break;
                                    }
                                case '2':
                                    {
                                        Console.Clear();
                                        char select = Methods.Teachermain();
                                        switch (select)
                                        {
                                            case '1':
                                                {
                                                    Methods.Teacherinsert();
                                                    break;
                                                }
                                            case '2':
                                                {
                                                    Methods.Teacherselect();
                                                    break;
                                                }
                                            case '3':
                                                {
                                                    Methods.Teacherdelete();
                                                    break;
                                                }
                                            case '4':
                                                {
                                                    Methods.MainMethod();
                                                    break;
                                                }
                                            default:
                                                break;
                                        }
                                        break;
                                    }
                                case '3':
                                    {
                                      
                                        Methods.blood();
                                        break;
                                    }
                                case '4':
                                    {
                                        Console.WriteLine(" ---------------------------------");
                                        Console.WriteLine("|\t Your Program has Closed      |");
                                        Console.WriteLine(" ---------------------------------");
                                        break;             
                                    }
                                default:
                                    {
                                        Console.WriteLine("Try Again");
                                        break;
                                    }
                            }
                        }
                        else if (ch == 'c' || ch == 'C')
                        {
                            Console.WriteLine(" ---------------------------------");
                            Console.WriteLine("|\t Your Program has Closed       |");
                            Console.WriteLine(" ---------------------------------");
                            break;
                        }
                    }
                    else
                    {
                        
                        char Choice = Methods.MainMethod();
                        Console.Clear();
                        switch (Choice)
                        {
                            case '1':
                                {
                                    Console.Clear();
                                    char pic = Methods.StudentMethod();
                                    switch (pic)
                                    {
                                        case '1':
                                            {
                                                Methods.StudentInsert();
                                                break;
                                            }
                                        case '2':
                                            {
                                                Methods.studentslect();
                                                break;
                                            }
                                        case '3':
                                            {
                                                Methods.studentsselete();
                                                break;
                                            }
                                        case '4':
                                            {
                                                Methods.studentsUpdate();
                                                break;
                                            }
                                        default:
                                            break;
                                    }
                                    break;
                                }
                            case '2':
                                {
                                    Console.Clear();
                                    char select = Methods.Teachermain();
                                    switch (select)
                                    {
                                        case '1':
                                            {
                                                Methods.Teacherinsert();
                                                break;
                                            }
                                        case '2':
                                            {
                                                Methods.Teacherselect();
                                                break;
                                            }
                                        case '3':
                                            {
                                                Methods.Teacherdelete();
                                                break;
                                            }
                                        case '4':
                                            {
                                                Methods.MainMethod();
                                                break;
                                            }
                                        default:
                                            break;
                                    }
                                    break;
                                }
                            case '3':
                                {
                                    Methods.blood();

                                    break;
                                }
                            case '4':
                                {
                                    Console.WriteLine(" ---------------------------------");
                                    Console.WriteLine("|\t Your Program has Closed      |");
                                    Console.WriteLine(" ---------------------------------");
                                    break;
                                }
                            default:
                                {
                                    Console.WriteLine("Try Again");
                                    break;
                                }
                        }
                    }
                }
                     
            }
            else
            {
                Console.WriteLine("No User found please enter correct username and password");
                Console.ReadKey();
            }
        }
    }
}
